﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace Stemee
{
    public partial class Form4 : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
        (
            int nLeftRect,     // x-coordinate of upper-left corner
            int nTopRect,      // y-coordinate of upper-left corner
            int nRightRect,    // x-coordinate of lower-right corner
            int nBottomRect,   // y-coordinate of lower-right corner
            int nWidthEllipse, // height of ellipse
            int nHeightEllipse // width of ellipse
        );

        public Form4()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.None;
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 18, 18));
        }

        private void toggleButton1_CheckedChanged(object sender, EventArgs e)
        {
            toggleButton1.Enabled = false;
            customButton1.Enabled = false;
            label2.Text = "...";
            if (toggleButton1.Checked)
            {
                timer1.Start();
            }

            else
            {
                timer2.Start();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            toggleButton1.Enabled = true;
            label2.Text = "ON";
            customButton1.Enabled = true;
            timer1.Stop();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            toggleButton1.Enabled = true;
            label2.Text = "OFF";
            timer2.Stop();
        }

        private void customButton1_Click(object sender, EventArgs e)
        {
            Process.Start("https://drive.google.com/uc?id=1XCMJ3GOH9N8gTg5-lZ_horgetPrSuHWX");
            Application.Exit();
        }
    }
}
