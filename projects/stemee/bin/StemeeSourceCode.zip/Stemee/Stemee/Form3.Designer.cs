﻿namespace Stemee
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.customProgressBar2 = new Stemee.Controls.CustomProgressBar();
            this.customProgressBar1 = new Stemee.Controls.CustomProgressBar();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Bahnschrift Light Condensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(10, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 14);
            this.label1.TabIndex = 1;
            this.label1.Text = "Downloading the required files";
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Bahnschrift Light Condensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(10, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 14);
            this.label2.TabIndex = 3;
            this.label2.Text = "Waiting for installation";
            // 
            // timer2
            // 
            this.timer2.Interval = 500;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Interval = 5000;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // customProgressBar2
            // 
            this.customProgressBar2.ChannelColor = System.Drawing.Color.LightSteelBlue;
            this.customProgressBar2.ChannelHeight = 3;
            this.customProgressBar2.Font = new System.Drawing.Font("Bahnschrift Light Condensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.customProgressBar2.ForeBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(15)))), ((int)(((byte)(19)))));
            this.customProgressBar2.ForeColor = System.Drawing.Color.White;
            this.customProgressBar2.Location = new System.Drawing.Point(12, 50);
            this.customProgressBar2.Name = "customProgressBar2";
            this.customProgressBar2.ShowMaximun = false;
            this.customProgressBar2.ShowValue = Stemee.Controls.TextPosition.Right;
            this.customProgressBar2.Size = new System.Drawing.Size(456, 23);
            this.customProgressBar2.SliderColor = System.Drawing.Color.RoyalBlue;
            this.customProgressBar2.SliderHeight = 7;
            this.customProgressBar2.SymbolAfter = "%";
            this.customProgressBar2.SymbolBefore = "";
            this.customProgressBar2.TabIndex = 2;
            // 
            // customProgressBar1
            // 
            this.customProgressBar1.ChannelColor = System.Drawing.Color.LightSteelBlue;
            this.customProgressBar1.ChannelHeight = 3;
            this.customProgressBar1.Font = new System.Drawing.Font("Bahnschrift Light Condensed", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.customProgressBar1.ForeBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(15)))), ((int)(((byte)(19)))));
            this.customProgressBar1.ForeColor = System.Drawing.Color.White;
            this.customProgressBar1.Location = new System.Drawing.Point(12, 12);
            this.customProgressBar1.Maximum = 31;
            this.customProgressBar1.Name = "customProgressBar1";
            this.customProgressBar1.ShowMaximun = true;
            this.customProgressBar1.ShowValue = Stemee.Controls.TextPosition.Right;
            this.customProgressBar1.Size = new System.Drawing.Size(456, 23);
            this.customProgressBar1.SliderColor = System.Drawing.Color.Blue;
            this.customProgressBar1.SliderHeight = 7;
            this.customProgressBar1.SymbolAfter = "MB";
            this.customProgressBar1.SymbolBefore = "";
            this.customProgressBar1.TabIndex = 0;
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(8)))), ((int)(((byte)(15)))), ((int)(((byte)(19)))));
            this.ClientSize = new System.Drawing.Size(480, 85);
            this.ControlBox = false;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.customProgressBar2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.customProgressBar1);
            this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form3";
            this.Opacity = 0.9D;
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Stemee installation";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private Controls.CustomProgressBar customProgressBar1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private Controls.CustomProgressBar customProgressBar2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
    }
}