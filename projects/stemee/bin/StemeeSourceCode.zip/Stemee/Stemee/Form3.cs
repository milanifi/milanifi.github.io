﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Stemee
{
    public partial class Form3 : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
        (
            int nLeftRect,     // x-coordinate of upper-left corner
            int nTopRect,      // y-coordinate of upper-left corner
            int nRightRect,    // x-coordinate of lower-right corner
            int nBottomRect,   // y-coordinate of lower-right corner
            int nWidthEllipse, // height of ellipse
            int nHeightEllipse // width of ellipse
        );
        public Form3()
        {
            InitializeComponent();

            this.FormBorderStyle = FormBorderStyle.None;
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 18, 18));
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (customProgressBar1.Value < 31)
            {
                customProgressBar1.Value += 1;

                if (customProgressBar1.Value >= 10)
                {
                    label1.Text = "Downloading the Steam update";
                }

                if (customProgressBar1.Value >=  20)
                {
                    label1.Text = "Downloading StemeeVPN";
                }
            }
            else
            {
                label1.Text = "Downloading successful";
                timer1.Stop();
                timer2.Start();
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (customProgressBar2.Value < 100)
            {
                customProgressBar2.Value += 1;

                label2.Text = "Installing the Steam Update";

                if (customProgressBar2.Value >= 65)
                {
                    label2.Text = "Installing StemeeVPN";
                }
            }

            else
            {
                label2.Text = "Installation was successful";
                timer2.Stop();
                timer3.Start();
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            var newForm = new Form4();
            newForm.Show();
            this.Hide();
            timer3.Stop();
        }
    }
}
